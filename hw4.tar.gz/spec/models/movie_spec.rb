require 'spec_helper'

describe Movie do

end